const { ref, required } = require("joi");
const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const Review=require('./review.js');
const { urlencoded } = require("express");

const listingSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: String,
  image: {
    url:String,
    filename:String
  },
  price: Number,
  location: String,
  country: String,
  reviews: [{
    type: Schema.Types.ObjectId,
    ref: 'Review'
  }],
  owner: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  geometry:{
    type:{
      type:String,
      enum:['Point'],
      required:true
    },
    coordinates:{
      type:[Number],
      required:true
    }
  }
});
listingSchema.post("findOneAndDelete", async function (listing) {
  if(listing){
await Review.deleteMany({_id:{$in:Listing.reviews}})
}});
const Listing = mongoose.model("Listing", listingSchema);
module.exports = Listing;
