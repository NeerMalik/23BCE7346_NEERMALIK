const express=require('express');
const router=express.Router({mergeParams:true});
const wrapAsync=require('../utils/wrapAsync.js')
const ExpressError=require('../utils/ExpressError.js')
const {listingSchema,reviewSchema}=require('../schema.js')
const Review=require('../models/review.js')
const Listing = require("../models/listing.js");
const { isLoggedIn,isOwner,isReviewAuthor,validateReview} = require('../middleware.js');
const ListingController=require('../controllers/review.js')





router.post("/",isLoggedIn,validateReview,wrapAsync(ListingController.createReview))
router.delete('/:reviewId',isLoggedIn,isReviewAuthor,wrapAsync(ListingController.deleteReview))


module.exports=router;