const express=require('express');
const router=express.Router();
const wrapAsync=require('../utils/wrapAsync.js')
const {listingSchema,reviewSchema}=require('../schema.js')
const ExpressError=require('../utils/ExpressError.js')
const Listing = require("../models/listing.js");
const { isLoggedIn,isOwner,validateListing} = require('../middleware.js');
const ListingController=require('../controllers/listings.js')
const multer = require('multer');
const { storage } = require('../cloudConfig.js');
const upload = multer({storage});

//index router for get and post route for create
router.route('/').get(wrapAsync(ListingController.index)).post(isLoggedIn,upload.single('listing[image]'),validateListing, wrapAsync(ListingController.createListing))
router.get("/new", isLoggedIn ,ListingController.renderNewForm);
// get for show and put for update and delete for delete route
router.route('/:id').get(wrapAsync(ListingController.showListing)).put(isLoggedIn,isOwner,upload.single('listing[image]'),validateListing,wrapAsync(ListingController.updateListing)).delete( isLoggedIn,isOwner,wrapAsync(ListingController.deleteListing));









//Edit Route
router.get("/:id/edit", isLoggedIn,isOwner,wrapAsync(ListingController.renderEditForm));





module.exports=router;